import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;
class Main {
  public static void main(String[] args) throws FileNotFoundException{
    Scanner scan = new Scanner(System.in);
    while(true){
    System.out.println("Enter your start base( type -1 to stop): ");
    int base = scan.nextInt();
      if(base==-1){
        return;
      }
    System.out.println("Enter the number to convert to base 10: ");
      int num = scan.nextInt();
    int sum = 0;
    int x = 0;
      while(num > 0){
       int digit = num%10;
        sum+= digit*Math.pow(base, x);
        x++;
        num/=10;
      }
    System.out.println("Your number in base 10 is: "+sum);
    }
  }
}